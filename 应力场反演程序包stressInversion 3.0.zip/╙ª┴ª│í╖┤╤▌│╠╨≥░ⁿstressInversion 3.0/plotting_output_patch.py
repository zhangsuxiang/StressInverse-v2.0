
# ============================================
# 绘图和输出补丁
# 添加到 StressInverse_improved.py 末尾
# ============================================

def generate_all_plots():
    """生成所有图形输出"""
    
    print("\n" + "="*60)
    print("开始生成图形和输出文件")
    print("="*60)
    
    # 确保必要的变量存在
    required_vars = {
        'shape_ratios_bootstrap': '形状比数组',
        'R_optimum': '最优R值',
        'R_std': 'R值标准差',
        'principal_stresses_optimum': '主应力值',
        'principal_axes_optimum': '主应力方向',
        'mu_optimum': '最优摩擦系数',
        'strikes': '走向',
        'dips': '倾角',
        'rakes': '滑动角',
        'P_azimuth': 'P轴方位',
        'P_plunge': 'P轴倾伏',
        'T_azimuth': 'T轴方位',
        'T_plunge': 'T轴倾伏',
        'planes_selection_optimum': '选定节面'
    }
    
    # 检查变量
    missing_vars = []
    for var_name, desc in required_vars.items():
        if var_name not in globals():
            missing_vars.append(f"{var_name} ({desc})")
    
    if missing_vars:
        print("\n警告：以下变量缺失：")
        for var in missing_vars:
            print(f"  - {var}")
    
    # 1. 形状比直方图
    print("\n1. 生成形状比直方图...")
    try:
        # 尝试使用原有模块
        try:
            from plot_stress import plot_shape_ratio
            plot_shape_ratio(
                shape_ratios_bootstrap,
                shape_ratio_axis,
                R_optimum,
                R_std,
                shape_ratio_plot
            )
            print("  ✓ 使用 plot_stress.plot_shape_ratio")
        except ImportError:
            # 如果原模块不存在，使用备用方法
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # 计算直方图
            hist, bins = np.histogram(shape_ratios_bootstrap, bins=shape_ratio_axis)
            width = bins[1] - bins[0]
            centers = (bins[:-1] + bins[1:]) / 2
            
            # 绘制
            ax.bar(centers, hist, width=width*0.8, alpha=0.7, color='blue')
            ax.axvline(R_optimum, color='red', linestyle='--', linewidth=2,
                      label=f'Optimum R = {R_optimum:.3f}')
            ax.axvspan(R_optimum - R_std, R_optimum + R_std,
                      alpha=0.2, color='red')
            
            ax.set_xlabel('Shape Ratio R')
            ax.set_ylabel('Frequency')
            ax.set_title('Distribution of Shape Ratio')
            ax.legend()
            ax.grid(True, alpha=0.3)
            
            plt.savefig(shape_ratio_plot + '.png', dpi=150, bbox_inches='tight')
            plt.savefig(shape_ratio_plot + '.pdf', bbox_inches='tight')
            plt.close()
            print("  ✓ 使用备用方法生成")
            
    except Exception as e:
        print(f"  ✗ 失败: {e}")
    
    # 2. 应力方向图
    print("\n2. 生成应力方向图...")
    try:
        try:
            from plot_stress import plot_stress_directions
            plot_stress_directions(
                principal_stresses_optimum,
                principal_axes_optimum,
                stress_plot
            )
            print("  ✓ 使用 plot_stress.plot_stress_directions")
        except ImportError:
            # 备用方法
            import matplotlib.pyplot as plt
            from matplotlib.patches import Circle
            
            fig, ax = plt.subplots(figsize=(8, 8))
            
            # 绘制圆
            circle = Circle((0, 0), 1, fill=False, edgecolor='black', linewidth=2)
            ax.add_patch(circle)
            
            # 投影主应力方向
            colors = ['red', 'green', 'blue']
            labels = ['σ₁', 'σ₂', 'σ₃']
            
            for i in range(3):
                axis = principal_axes_optimum[:, i]
                if axis[2] < 0:
                    axis = -axis
                
                # 简单立体投影
                x = axis[1] / (1 + axis[2])
                y = axis[0] / (1 + axis[2])
                
                ax.plot(x, y, 'o', color=colors[i], markersize=15,
                       label=f'{labels[i]}: {principal_stresses_optimum[i]:.3f}')
            
            ax.set_xlim(-1.2, 1.2)
            ax.set_ylim(-1.2, 1.2)
            ax.set_aspect('equal')
            ax.set_xlabel('East')
            ax.set_ylabel('North')
            ax.set_title('Principal Stress Directions (Lower Hemisphere)')
            ax.legend()
            ax.grid(True, alpha=0.3)
            
            plt.savefig(stress_plot + '.png', dpi=150, bbox_inches='tight')
            plt.savefig(stress_plot + '.pdf', bbox_inches='tight')
            plt.close()
            print("  ✓ 使用备用方法生成")
            
    except Exception as e:
        print(f"  ✗ 失败: {e}")
    
    # 3. P-T轴图
    print("\n3. 生成P-T轴图...")
    try:
        try:
            from plot_stress_axes import plot_P_T_axes
            plot_P_T_axes(
                P_azimuth, P_plunge,
                T_azimuth, T_plunge,
                principal_axes_optimum,
                P_T_plot
            )
            print("  ✓ 使用 plot_stress_axes.plot_P_T_axes")
        except ImportError:
            # 备用方法
            import matplotlib.pyplot as plt
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
            
            # P轴
            ax1.scatter(P_azimuth, P_plunge, alpha=0.6, s=30, color='red')
            ax1.set_xlabel('Azimuth (°)')
            ax1.set_ylabel('Plunge (°)')
            ax1.set_title('P-axes Distribution')
            ax1.set_xlim(0, 360)
            ax1.set_ylim(0, 90)
            ax1.grid(True, alpha=0.3)
            
            # T轴
            ax2.scatter(T_azimuth, T_plunge, alpha=0.6, s=30, color='blue')
            ax2.set_xlabel('Azimuth (°)')
            ax2.set_ylabel('Plunge (°)')
            ax2.set_title('T-axes Distribution')
            ax2.set_xlim(0, 360)
            ax2.set_ylim(0, 90)
            ax2.grid(True, alpha=0.3)
            
            plt.suptitle('P-T Axes Distribution')
            plt.tight_layout()
            
            plt.savefig(P_T_plot + '.png', dpi=150, bbox_inches='tight')
            plt.savefig(P_T_plot + '.pdf', bbox_inches='tight')
            plt.close()
            print("  ✓ 使用备用方法生成")
            
    except Exception as e:
        print(f"  ✗ 失败: {e}")
    
    # 4. 莫尔圆图
    print("\n4. 生成莫尔圆图...")
    try:
        try:
            from plot_mohr import plot_Mohr
            plot_Mohr(
                principal_stresses_optimum,
                mu_optimum,
                0.0,  # cohesion
                strikes, dips, rakes,
                principal_axes_optimum,
                Mohr_plot
            )
            print("  ✓ 使用 plot_mohr.plot_Mohr")
        except ImportError:
            # 备用方法
            import matplotlib.pyplot as plt
            from matplotlib.patches import Circle
            
            fig, ax = plt.subplots(figsize=(10, 8))
            
            s1, s2, s3 = principal_stresses_optimum
            
            # 莫尔圆
            center1 = (s1 + s3) / 2
            radius1 = (s1 - s3) / 2
            circle1 = Circle((center1, 0), radius1, fill=False,
                           edgecolor='red', linewidth=2, label='σ₁-σ₃')
            ax.add_patch(circle1)
            
            center2 = (s1 + s2) / 2
            radius2 = (s1 - s2) / 2
            circle2 = Circle((center2, 0), radius2, fill=False,
                           edgecolor='green', linewidth=2, label='σ₁-σ₂')
            ax.add_patch(circle2)
            
            center3 = (s2 + s3) / 2
            radius3 = (s2 - s3) / 2
            circle3 = Circle((center3, 0), radius3, fill=False,
                           edgecolor='blue', linewidth=2, label='σ₂-σ₃')
            ax.add_patch(circle3)
            
            # 破裂准则线
            sigma_n = np.linspace(s3 - 0.5, s1 + 0.5, 100)
            tau_failure = mu_optimum * sigma_n
            ax.plot(sigma_n, tau_failure, 'k--', linewidth=2,
                   label=f'Failure (μ={mu_optimum:.2f})')
            ax.plot(sigma_n, -tau_failure, 'k--', linewidth=2)
            
            ax.set_xlabel('Normal Stress σₙ')
            ax.set_ylabel('Shear Stress τ')
            ax.set_title('Mohr Circles and Failure Criterion')
            ax.axhline(y=0, color='k', linewidth=0.5)
            ax.axvline(x=0, color='k', linewidth=0.5)
            ax.grid(True, alpha=0.3)
            ax.legend()
            ax.set_aspect('equal')
            
            ax.set_xlim(s3 - 0.5, s1 + 0.5)
            max_tau = max(radius1, radius2, radius3) * 1.2
            ax.set_ylim(-max_tau, max_tau)
            
            plt.savefig(Mohr_plot + '.png', dpi=150, bbox_inches='tight')
            plt.savefig(Mohr_plot + '.pdf', bbox_inches='tight')
            plt.close()
            print("  ✓ 使用备用方法生成")
            
    except Exception as e:
        print(f"  ✗ 失败: {e}")
    
    # 5. 断层分布图（可选）
    print("\n5. 生成断层分布图...")
    try:
        try:
            from plot_stress import plot_faults
            plot_faults(
                strikes, dips, rakes,
                planes_selection_optimum,
                principal_axes_optimum,
                faults_plot
            )
            print("  ✓ 使用 plot_stress.plot_faults")
        except:
            # 备用方法 - 玫瑰图
            import matplotlib.pyplot as plt
            
            fig = plt.figure(figsize=(12, 6))
            
            # 走向玫瑰图
            ax1 = plt.subplot(121, projection='polar')
            strikes_rad = np.radians(strikes)
            bins = np.linspace(0, 2*np.pi, 37)
            hist, _ = np.histogram(strikes_rad, bins=bins)
            theta = (bins[:-1] + bins[1:]) / 2
            width = bins[1] - bins[0]
            
            bars = ax1.bar(theta, hist, width=width, bottom=0)
            for bar, val in zip(bars, hist):
                bar.set_facecolor(plt.cm.viridis(val / max(hist)))
            
            ax1.set_theta_zero_location('N')
            ax1.set_theta_direction(-1)
            ax1.set_title('Strike Distribution')
            
            # 倾角直方图
            ax2 = plt.subplot(122)
            ax2.hist(dips, bins=18, range=(0, 90), alpha=0.7,
                    color='blue', edgecolor='black')
            ax2.set_xlabel('Dip (°)')
            ax2.set_ylabel('Frequency')
            ax2.set_title('Dip Distribution')
            ax2.grid(True, alpha=0.3)
            
            plt.suptitle('Fault Geometry Distribution')
            plt.tight_layout()
            
            plt.savefig(faults_plot + '.png', dpi=150, bbox_inches='tight')
            plt.savefig(faults_plot + '.pdf', bbox_inches='tight')
            plt.close()
            print("  ✓ 使用备用方法生成")
            
    except Exception as e:
        print(f"  ✗ 失败: {e}")
    
    print("\n" + "="*60)
    print("图形生成完成")
    print("="*60)

# 调用绘图函数
generate_all_plots()

# 生成输出文件
def save_output_files():
    """保存输出文件"""
    
    print("\n" + "="*60)
    print("保存输出文件")
    print("="*60)
    
    # 1. 主要结果文件
    try:
        with open(output_file + '.txt', 'w') as f:
            f.write("="*60 + "\n")
            f.write("应力反演结果\n")
            f.write("="*60 + "\n\n")
            
            f.write(f"使用方法: {inversion_method}\n\n")
            
            f.write("最优应力张量:\n")
            f.write(f"{tau_optimum}\n\n")
            
            f.write("主应力值:\n")
            f.write(f"σ1 = {principal_stresses_optimum[0]:.4f}\n")
            f.write(f"σ2 = {principal_stresses_optimum[1]:.4f}\n")
            f.write(f"σ3 = {principal_stresses_optimum[2]:.4f}\n\n")
            
            f.write(f"形状比 R = {R_optimum:.4f} ± {R_std:.4f}\n")
            f.write(f"摩擦系数 μ = {mu_optimum:.3f}\n\n")
            
            f.write("主应力方向 (North, East, Down):\n")
            for i in range(3):
                f.write(f"σ{i+1}: [{principal_axes_optimum[0,i]:.4f}, "
                       f"{principal_axes_optimum[1,i]:.4f}, "
                       f"{principal_axes_optimum[2,i]:.4f}]\n")
        
        print(f"  ✓ 主结果文件: {output_file}.txt")
        
    except Exception as e:
        print(f"  ✗ 主结果文件失败: {e}")
    
    # 2. 震源机制文件
    try:
        with open(principal_mechanisms_file + '.txt', 'w') as f:
            f.write("# Strike  Dip  Rake  Selected_Plane\n")
            for i in range(len(strikes)):
                f.write(f"{strikes[i]:7.2f} {dips[i]:5.2f} {rakes[i]:7.2f} "
                       f"{planes_selection_optimum[i]:2d}\n")
        
        print(f"  ✓ 震源机制文件: {principal_mechanisms_file}.txt")
        
    except Exception as e:
        print(f"  ✗ 震源机制文件失败: {e}")
    
    print("\n" + "="*60)
    print("输出文件保存完成")
    print("="*60)

# 保存输出文件
save_output_files()
