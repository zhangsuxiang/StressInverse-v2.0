# stress_inversion_ilsi.py
# 使用ILSI迭代线性方法的改进版应力反演函数

import numpy as np
import sys
import os

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入ILSI核心函数
try:
    # 从ilsi.py文件导入需要的函数
    from ilsi import iterative_linear_si, Michael1984_inversion
    from utils_stress import normal_slip_vectors, stress_tensor_eigendecomposition, R_
except ImportError as e:
    print(f"警告：无法导入ILSI模块 - {e}")
    print("将使用简化版本...")
    
    # 如果ILSI模块不可用，定义一个简化版本
    def iterative_linear_si(strikes, dips, rakes, **kwargs):
        """简化版迭代线性反演（实际使用Michael方法）"""
        return Michael1984_inversion(strikes, dips, rakes, **kwargs)
    
    def Michael1984_inversion(strikes, dips, rakes, **kwargs):
        """简化版Michael反演"""
        from statistics_stress_inversion import linear_stress_inversion
        stress = linear_stress_inversion(strikes, dips, rakes)
        
        # 计算特征值和特征向量
        eigenvalues, eigenvectors = np.linalg.eigh(stress)
        order = np.argsort(eigenvalues)
        eigenvalues = eigenvalues[order]
        eigenvectors = eigenvectors[:, order]
        
        return {
            "stress_tensor": stress,
            "principal_stresses": eigenvalues,
            "principal_directions": eigenvectors
        }

# 导入其他必要模块
from advanced_stability_criterion import advanced_stability_criterion
from statistics_stress_inversion import linear_stress_inversion

def stress_inversion_with_ilsi(strike1_orig, dip1_orig, rake1_orig, 
                               strike2_orig, dip2_orig, rake2_orig,
                               friction_min, friction_max, friction_step,
                               N_iterations, N_realizations,
                               instability_ratio_threshold=1.4,
                               deviation_angle_good=20.0,
                               deviation_angle_bad=30.0,
                               use_variable_shear=True,
                               max_shear_iterations=100,
                               shear_tolerance=1e-5):
    """
    使用ILSI迭代线性方法或Michael方法的改进应力反演函数
    
    参数说明见原始文档...
    """
    
    print(f"使用{'迭代线性方法(ILSI)' if use_variable_shear else 'Michael方法'}")
    
    # 初始应力估计
    print("初始化应力张量...")
    
    n_mechanisms = len(strike1_orig)
    stress_tensors = []
    
    # 多次随机选择断层面进行初始估计
    for i_realization in range(N_realizations):
        # 随机选择节面
        all_strikes = np.zeros(n_mechanisms)
        all_dips = np.zeros(n_mechanisms)
        all_rakes = np.zeros(n_mechanisms)
        
        for i in range(n_mechanisms):
            if np.random.rand() > 0.5:
                all_strikes[i] = strike1_orig[i]
                all_dips[i] = dip1_orig[i]
                all_rakes[i] = rake1_orig[i]
            else:
                all_strikes[i] = strike2_orig[i]
                all_dips[i] = dip2_orig[i]
                all_rakes[i] = rake2_orig[i]
        
        # 使用线性反演获得初始应力
        try:
            if use_variable_shear:
                # 尝试使用ILSI方法
                output = iterative_linear_si(
                    all_strikes, all_dips, all_rakes,
                    max_n_iterations=max_shear_iterations,
                    shear_update_atol=shear_tolerance,
                    return_eigen=True,
                    return_stats=False
                )
                stress_tensors.append(output["stress_tensor"])
            else:
                # 使用Michael方法
                output = Michael1984_inversion(
                    all_strikes, all_dips, all_rakes,
                    return_eigen=True,
                    return_stats=False
                )
                stress_tensors.append(output["stress_tensor"])
        except Exception as e:
            # 如果出错，使用基础线性反演
            print(f"初始反演出错，使用基础方法: {e}")
            stress = linear_stress_inversion(all_strikes, all_dips, all_rakes)
            stress_tensors.append(stress)
    
    # 平均初始应力张量
    tau0 = np.mean(stress_tensors, axis=0)
    tau0 = tau0 / np.linalg.norm(tau0, 'fro')
    
    print(f"搜索最优摩擦系数 ({friction_min:.2f} - {friction_max:.2f})...")
    
    # 搜索最优摩擦系数
    friction_range = np.arange(friction_min, friction_max + friction_step, friction_step)
    mean_instability = np.zeros(len(friction_range))
    n_selected = np.zeros(len(friction_range))
    best_results = {}
    
    for i_friction, friction in enumerate(friction_range):
        tau_current = tau0.copy()
        
        # 迭代优化
        for i_iteration in range(N_iterations):
            # 使用两阶段稳定性准则选择节面
            strike, dip, rake, instability, selected_indices, selection_method = \
                advanced_stability_criterion(
                    tau_current, friction,
                    strike1_orig, dip1_orig, rake1_orig,
                    strike2_orig, dip2_orig, rake2_orig,
                    instability_ratio_threshold,
                    deviation_angle_good,
                    deviation_angle_bad
                )
            
            if len(strike) > 0:
                # 更新应力张量
                try:
                    if use_variable_shear:
                        output = iterative_linear_si(
                            strike, dip, rake,
                            max_n_iterations=max_shear_iterations,
                            shear_update_atol=shear_tolerance,
                            return_eigen=True,
                            return_stats=False
                        )
                        tau_current = output["stress_tensor"]
                    else:
                        tau_current = linear_stress_inversion(strike, dip, rake)
                except:
                    # 如果ILSI方法失败，使用基础方法
                    tau_current = linear_stress_inversion(strike, dip, rake)
                
                # 存储结果
                if i_iteration == N_iterations - 1:
                    best_results[friction] = {
                        'tau': tau_current,
                        'strike': strike,
                        'dip': dip,
                        'rake': rake,
                        'instability': instability,
                        'selected_indices': selected_indices,
                        'selection_method': selection_method
                    }
        
        # 记录统计
        if len(instability) > 0:
            mean_instability[i_friction] = np.mean(instability)
            n_selected[i_friction] = len(instability)
        else:
            mean_instability[i_friction] = 0
            n_selected[i_friction] = 0
    
    # 选择最优摩擦系数
    min_data_fraction = 0.3
    min_data_count = int(len(strike1_orig) * min_data_fraction)
    
    valid_frictions = n_selected >= min_data_count
    if np.any(valid_frictions):
        valid_mean_instability = mean_instability.copy()
        valid_mean_instability[~valid_frictions] = -np.inf
        i_optimum = np.argmax(valid_mean_instability)
    else:
        i_optimum = np.argmax(n_selected)
    
    friction_optimum = friction_range[i_optimum]
    
    print(f"最优摩擦系数: {friction_optimum:.2f}")
    print(f"选择的数据数: {int(n_selected[i_optimum])}/{len(strike1_orig)}")
    
    # 获取最优结果
    if friction_optimum in best_results:
        optimal_result = best_results[friction_optimum]
        tau_optimum = optimal_result['tau']
        strike = optimal_result['strike']
        dip = optimal_result['dip']
        rake = optimal_result['rake']
        instability = optimal_result['instability']
        selected_indices = optimal_result['selected_indices']
        selection_method = optimal_result['selection_method']
    else:
        # 如果没有找到结果，返回空值
        tau_optimum = tau0
        strike = np.array([])
        dip = np.array([])
        rake = np.array([])
        instability = np.array([])
        selected_indices = np.array([])
        selection_method = np.zeros(len(strike1_orig))
    
    # 计算统计信息
    n_total = len(strike1_orig)
    n_selected_instability = np.sum(selection_method == 1)
    n_selected_deviation = np.sum(selection_method == 2)
    n_discarded = np.sum(selection_method == 0)
    
    selection_stats = {
        'n_total': n_total,
        'n_selected': len(selected_indices),
        'n_selected_instability': int(n_selected_instability),
        'n_selected_deviation': int(n_selected_deviation),
        'n_discarded': int(n_discarded),
        'selection_method': selection_method
    }
    
    # 计算应力形状比
    eigenvalues = np.sort(np.linalg.eigvals(tau_optimum))
    if eigenvalues[0] != eigenvalues[2]:
        shape_ratio = (eigenvalues[0] - eigenvalues[1]) / (eigenvalues[0] - eigenvalues[2])
    else:
        shape_ratio = 0.5
    
    return (tau_optimum, shape_ratio, strike, dip, rake, instability, 
            friction_optimum, selected_indices, selection_stats)